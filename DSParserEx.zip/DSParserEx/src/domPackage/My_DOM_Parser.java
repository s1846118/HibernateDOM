package domPackage;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class My_DOM_Parser {
	
	public My_DOM_Parser() {
		
	}
	
	//created this method to add country codes to object - also need to do this for values and number of detections variant
	public ArrayList<String> getCountryCode(NodeList sheets1){
		
		ArrayList<String> countryCode = new ArrayList<>();
		
		for(int i = 0; i < sheets1.getLength(); i++) {
			Node n = sheets1.item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				Element m = (Element) n;
				NodeList record = m.getChildNodes();
				
				for(int y = 0; y < record.getLength(); y++) {
					Node att = record.item(y);
					if(att.getNodeType() == Node.ELEMENT_NODE) {
						Element att1 = (Element) att;
						
						// Check if we are on the country tag, if so then add the country if we haven't already
						if (att1.getTagName() == "fme:country_code" && !countryCode.contains(att1.getTextContent())) {
							countryCode.add(att1.getTextContent());
						}
					}
				}
			}
		}
		return countryCode;
		
	}
	
	public ArrayList<String> getVariants(NodeList countryNode, String where, String weekYear) {
		// Going through every country node
		ArrayList<String> variants = new ArrayList<>();
		// For loops through each country node
		for (int i = 0; i < countryNode.getLength(); i++) {
			
			Node country = countryNode.item(i);
			// Screens for specific country, need to check element because this tells us we checking content not tag
			if (country.getTextContent().equals(where)) {
				
				// Crawl along the XML tree and get relevant nodes
				
				//This should be the year week node
				Node c = country.getNextSibling().getNextSibling().getNextSibling().getNextSibling();
				// If true then we on specific week year and we want to parse the variants
				if(c != null && c.getTextContent().equals(weekYear)) {
					
					// Now grab variants if not null 
					Node variant = c.getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling();
					//12 - could have possibly used for loop
					
					// Here we check if the variant if in our list and add if not 
					if (variant != null) {
						String current_variant = variant.getTextContent();
						
						//Check if multiple variants in element
						if(current_variant.contains("/")) {
							String[] vars = current_variant.split("/");
							
							//Add each variant
							for(String var : vars) {
								if(!variants.contains(var)) {
									variants.add(var);
								}
							}
						} else if (!variants.contains(current_variant)) {
							variants.add(current_variant);
						}
					}				
				}
			}
		}
		
		return variants;
		
	}
	
	//NodeList of fme:country elements, String where is the country, weekYear is the weekYear form yyyy-wkX
	public float countryWeekAvg(NodeList Aus, String where, String weekYear){
		// Going through every country node
		float result = 0;
		float length = 0;
		// For loops through each country node
		for (int i = 0; i < Aus.getLength(); i++) {
			
			Node country = Aus.item(i);
			// Screens for specific country, need to check element because this tells us we checking content not tag
			if (country.getTextContent().equals(where)) {
				
				// Crawl along the XML tree and get relevant nodes
				Node sibling = country.getNextSibling();
				while (sibling != null) {
					
					if (sibling.getNodeType() == Node.ELEMENT_NODE) {
						Element e = (Element) sibling;
						
						if(e.getTagName().equals("fme:year_week") && e.getTextContent().contains(weekYear)) {
							
							//Double get next sibling lol because get next sibling returns the text from the year-week node
							Node grab_val = sibling.getNextSibling().getNextSibling();
							
							if(grab_val.getNodeType() == Node.ELEMENT_NODE) {
								Element elementVal = (Element) grab_val;
	
								float f = Float.parseFloat(elementVal.getTextContent());
								result += f;
								length += 1;
							}
							
							break;
						}
						if(e.getTagName().equals("fme:year_week") && !e.getTextContent().contains(weekYear)) {
							break;
						}
					}
					sibling = sibling.getNextSibling();
				}
			}
		}
		
		return result/length;
	}
	
	//calld in line 52 of App.java class
	public ArrayList<String> getCountries(NodeList sheets){
		
		ArrayList<String> Countries = new ArrayList<>();
		
		for(int i = 0; i < sheets.getLength(); i++) {
			Node n = sheets.item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				Element m = (Element) n;
				NodeList record = m.getChildNodes();
				
				for(int y = 0; y < record.getLength(); y++) {
					Node att = record.item(y);
					if(att.getNodeType() == Node.ELEMENT_NODE) {
						Element att1 = (Element) att;
						
						// Check if we are on the country tag, if so then add the country if we haven't already
						if (att1.getTagName() == "fme:country" && !Countries.contains(att1.getTextContent())) {
							Countries.add(att1.getTextContent());
						}
					}
				}
			}
		}
		return Countries;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		ArrayList<String> Countries = new ArrayList<>();

		
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse("xml2.xml");
			NodeList sheets = doc.getElementsByTagName("fme:Sheet");
			NodeList Aus = doc.getElementsByTagName("fme:country");
			
			DocumentBuilder builder2 = factory.newDocumentBuilder();
			Document doc2 = builder2.parse("xml3.xml");
			NodeList sheets2 = doc2.getElementsByTagName("fme:Sheet");
			NodeList Aus2 = doc2.getElementsByTagName("fme:country");
			
			NodeList sheets1 = doc2.getElementsByTagName("fme:Sheet");
			NodeList Aus3 = doc2.getElementsByTagName("fme:country_code");
			
			My_DOM_Parser dp = new My_DOM_Parser();
			
			System.out.println(dp.countryWeekAvg(Aus, "Hungry", "2022-W21"));
			System.out.println(dp.getCountries(sheets));
			System.out.println(dp.getCountryCode(sheets1));

			System.out.println(dp.getVariants(Aus2, "Hungry", "2022-21"));
			System.out.println(dp.getVariants(Aus2, "Hungry", "2022-21"));
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
