package domPackage;

public class Practise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[10];
		int i;
		
		for (i = 0; i < 10; i++) {
			
			arr[i] = i + 100;
			
			System.out.println(i + 100);
			System.out.println(i);
			
		}

	}

}
