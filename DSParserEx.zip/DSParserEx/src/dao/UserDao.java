package dao;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import main.User;

public interface UserDao {

static EntityManagerFactory emf = Persistence.createEntityManagerFactory("ca2EXPU");
/*
 * public UserDAO() {
 * 
 * }
 */
	
	void saveUser(User user);

}

//User getUserById(long id);
//
//List<User> getAllUsers();
//
//void updateUser(User user);
//
//void deleteUserById(long id);