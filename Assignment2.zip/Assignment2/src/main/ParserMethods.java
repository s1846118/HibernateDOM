package main;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ParserMethods {
	
	public ParserMethods() {
		
	}
	
	public ArrayList<String> getVariants(NodeList countryNode, String where, String weekYear) {
		//goes through each country node
		ArrayList<String> variants = new ArrayList<>();
		
		//loops through each country node
		for (int i = 0; i < countryNode.getLength(); i++) {
			
			Node country = countryNode.item(i);
			if (country.getTextContent().equals(where)) {
		
				//this should be the year week node - 4th one down the list
				Node c = country.getNextSibling().getNextSibling().getNextSibling().getNextSibling();
				
				// if condition is true then a specific week year is on, and variants need to be parsed
				if(c != null && c.getTextContent().equals(weekYear)) {
					
					// grab all variants if they are not null
					Node variant = c.getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling();
					
					// now check if the variant if in the list and add to list if not 
					if (variant != null) {
						String current_variant = variant.getTextContent();
						
						//check if there are multiple variants in element
						if(current_variant.contains("/")) {
							String[] vars = current_variant.split("/");
							
							//sdd each variant
							for(String var : vars) {
								if(!variants.contains(var)) {
									variants.add(var);
								}
							}
						} else if (!variants.contains(current_variant)) {
							variants.add(current_variant);
						}
					}				
				}
			}
		}
		
		return variants;		
	}
	
	
	//NodeList of fme:country elements, String where is the country, weekYear is the weekYear in the format yyyy-wkX
	public float countryWeekAvg(NodeList Aus, String where, String weekYear){
		//going through each country node
		float result = 0;
		float length = 0;
		//loop through each country node
		for (int i = 0; i < Aus.getLength(); i++) {
			
			Node country = Aus.item(i);
			//screens for specific country, need to check element because this shows we are checking content not tag
			if (country.getTextContent().equals(where)) {
				
				//getting relevant nodes
				Node sibling = country.getNextSibling();
				while (sibling != null) {
					
					if (sibling.getNodeType() == Node.ELEMENT_NODE) {
						Element e = (Element) sibling;
						
						if(e.getTagName().equals("fme:year_week") && e.getTextContent().contains(weekYear)) {
							
							//2 getNextSibling() methods because  getNextSibling() returns the text from the year-week node
							Node grab_val = sibling.getNextSibling().getNextSibling();
							
							if(grab_val.getNodeType() == Node.ELEMENT_NODE) {
								Element elementVal = (Element) grab_val;
	
								float f = Float.parseFloat(elementVal.getTextContent());
								result += f;
								length += 1;
							}		
							break;
						}
						if(e.getTagName().equals("fme:year_week") && !e.getTextContent().contains(weekYear)) {
							break;
						}
					}
					sibling = sibling.getNextSibling();
				}
			}
		}
		return result/length;
	}
	
	
	
	//NodeList of fme:country elements, String where is the country, weekYear is the weekYear in theform yyyy-wkX
	public float countryNoDetVarAvg(NodeList Aus, String where, String weekYear){
		
		//goes through every country node
		float result = 0f;
		float length = 0f;
		
		//loop through every country node
		for (int i = 0; i < Aus.getLength(); i++) {
			
			Node country = Aus.item(i);
			
			//screens for specific country, need to check element because this tells us we checking content not tag
			if (country.getTextContent().equals(where)) {
				
				//getting relevant nodes
				Node sibling = country.getNextSibling();
				while (sibling != null) {
					
					if (sibling.getNodeType() == Node.ELEMENT_NODE) {
						Element e = (Element) sibling;
						
						if(e.getTagName().equals("fme:year_week") && e.getTextContent().contains(weekYear)) {
							//must go along 15 siblings to grab the number of detected variants for the specific node
							Node grab_val = sibling.getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling();
							
							if (grab_val.getNodeType() == Node.ELEMENT_NODE) {
								Element gEl = (Element) grab_val;
								float f = Float.parseFloat(gEl.getTextContent());
								System.out.println(f);
								result += f;
								length += 1;
							}
							break;
						}
						if(e.getTagName().equals("fme:year_week") && !e.getTextContent().contains(weekYear)) {
							break;
						}
					}
					sibling = sibling.getNextSibling();
				}
			}
		}	
		return result/length;
	}
	
	
	
	
	public ArrayList<String[]> getCountries(NodeList sheets){
		
		ArrayList<String[]> Countries = new ArrayList<>();
		
		//checking for countries in above arraylist
		ArrayList<String> countryReference = new ArrayList<>();
		
		
		for(int i = 0; i < sheets.getLength(); i++) {
			Node n = sheets.item(i);
			
			
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				Element m = (Element) n;
				NodeList record = m.getChildNodes();
				
				
				
				for(int y = 0; y < record.getLength(); y++) {
					Node att = record.item(y);
					if(att.getNodeType() == Node.ELEMENT_NODE) {
						Element att1 = (Element) att;
						
						//checking if we are on the country tag, if so then adding the country if it hasn't been added already
						if (att1.getTagName() == "fme:country" && !countryReference.contains(att1.getTextContent())) {
							countryReference.add(att1.getTextContent());
							String[] arr = {att1.getTextContent(), att.getNextSibling().getNextSibling().getTextContent()};
							Countries.add(arr);
						}
					}
				}
			}
		}
		return Countries;
	}


	public static void main(String[] args) {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		ArrayList<String> countries = new ArrayList<>();
	
		
		try {
			//DocumentBuilder object
			DocumentBuilder builder = factory.newDocumentBuilder();
			//parse the xml document
			Document doc = builder.parse("coviddata.xml");
			
			NodeList sheets = doc.getElementsByTagName("fme:Sheet");
			NodeList Aus = doc.getElementsByTagName("fme:country");
			
			//DocumentBuilder object
			DocumentBuilder builder2 = factory.newDocumentBuilder();
			//parse the xml document
			Document doc2 = builder2.parse("variant.xml");
			
			NodeList sheets2 = doc2.getElementsByTagName("fme:Sheet");
			NodeList Aus2 = doc2.getElementsByTagName("fme:country");
			
			//ParserMethods object
			ParserMethods method = new ParserMethods();
			
			System.out.println(method.countryWeekAvg(Aus, "Hungry", "2022-W21"));
			System.out.println(method.getCountries(sheets));
			System.out.println(method.getVariants(Aus2, "Hungry", "2022-21"));
			System.out.println(method.getVariants(Aus2, "Hungry", "2022-21"));
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}

}


