package main;

import java.util.List;

import entities.CovidData;
import entities.User;

//interface for functions
public interface CovidDataFunctions {
	//persisting coviddata and users
	CovidData persist(CovidData covidData);
	User persist (User user);
	
	//displaying all coviddata and users
	List<CovidData> findAll();
	List<User> findAllUsers();
	
	//updating coviddata and users
	User update (User user);	
	CovidData update(CovidData covidData);
	
	//deleting coviddata and users
	void remove(String username);
	void removeCountry(String country);

}
