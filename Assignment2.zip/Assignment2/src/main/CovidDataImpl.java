package main;

import java.util.List;

import entities.CovidData;
import entities.User;

//implementation of functions in CovidDataFunctions interface
public class CovidDataImpl implements CovidDataFunctions {
	
	
	private CovidDataFunctions covidDF;
	
	@Override
	public CovidData persist(CovidData covidData) {
		return covidDF.persist(covidData);
	}
	
	@Override
	public User persist(User user) {
		return covidDF.persist(user);
	}

	
	@Override
	public List<CovidData> findAll() {
		// TODO Auto-generated method stub
		return covidDF.findAll();
	}

	
	@Override
	public User update(User user) {
		return covidDF.update(user);
	}

	@Override
	public CovidData update(CovidData covidData) {
		return covidDF.update(covidData);
	}
	@Override
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(String username) {
		covidDF.remove(username);
	}

	@Override
	public void removeCountry(String country) {
		covidDF.removeCountry(country);
	}

	

}
