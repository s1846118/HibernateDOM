package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.mysql.cj.log.Log;

import dao.CovidDataDAO;
import dao.UserDAO;
import entities.CovidData;
import entities.User;
import main.ParserMethods;

@Path("countrycovidInfo")
public class Parser {
	
	//DAO objects for UserDAO and CovidDataDAO 
	static CovidDataDAO cdDAO = new CovidDataDAO();
	static UserDAO uDAO = new UserDAO();
    public static void main( String[] args ) {
    	

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		try {
			//DocumentBuilder object
			DocumentBuilder builder = factory.newDocumentBuilder();
			DocumentBuilder builder2 = factory.newDocumentBuilder();
			
			//parse xml 
			Document doc = builder.parse("coviddata.xml"); //covid
			Document doc2 = builder2.parse("variant.xml"); //variant
			
			//method object 
			ParserMethods method = new ParserMethods();
			
			//get nodes from sheet and country nodes from coviddata.xml
			NodeList sheets = doc.getElementsByTagName("fme:Sheet");
			NodeList Aus = doc.getElementsByTagName("fme:country");
			
			//get nodes from sheet and country nodes from variant.xml
			NodeList sheets2 = doc2.getElementsByTagName("fme:Sheet");
			NodeList Aus2 = doc2.getElementsByTagName("fme:country");		
	
			//Get all countries
			ArrayList<String[]> countries = method.getCountries(sheets2);
			
			//grab relevant data for each country from the last 10 weeks
			for (String[] country : countries) {
				
				for (int i = 30; i > 21; i--) {
					
					//converting i to string to pass to relevant functions
					String week = String.valueOf(i);
					
					float NoCases = method.countryWeekAvg(Aus, country[0], "2020-W"+week);
					float noDetVarsAvg = method.countryNoDetVarAvg(Aus2, country[0], "2022-"+week);
					ArrayList<String> variantsCountry = method.getVariants(Aus2, country[0], "2022-"+week);
					
					//concat each variant into one big string 
					String varObj = "";
					for (String var : variantsCountry) {
						varObj += " " + var;
					}
					if(NoCases == 0.0f) {
						NoCases = -1f;
						System.out.println("No cases");
					}
					if(varObj == "") {
						varObj = "NA";
						System.out.println("No variants");
					}
					
					System.out.println("Country: "+country[0] + ", Country Code: " + country[1] + ", Cases: "+ NoCases + ", Variant: " + varObj + ", Week: 2022-W"+week + ", No Detec Variants: " + noDetVarsAvg);
					
					//create CovidData object
			    	CovidData covidData1 = new CovidData(country[0], NoCases, varObj, "2022-W"+week, country[1], noDetVarsAvg);
			    	//persist this object to mySQL db using cdDAO object
			    	cdDAO.persist(covidData1);
					
				}
			}
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		//was't completely sure, but I thought that to display the data from myDQL with REST, some kind of jdbc connection would
		//have needed to be made - had a bit of trouble with this part, hence why I commented it out
		/*
		 * Connection connection; try { connection = DriverManager.getConnection(
		 * "jdbc:mysql://127.0.0.1:3306/ca2EX?serverTimezone=UTC", "root", "root");
		 * Statement statement = connection.createStatement(); ResultSet rs =
		 * statement.executeQuery("select * from user");
		 * 
		 * while(rs.next()) { System.out.println(rs.getString("Country: ") + "\t" +
		 * rs.getString("Country Code: ") + "\t" + rs.getString("Cases: ") + "\t" +
		 * rs.getString("Variants: ") + "\t" + rs.getString("Year_Week: ") +
		 * rs.getString("No Variants Detected: ")); }
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

    	}
    
    
    private CovidDataFunctions covidDataFunc;
    private User user;
    
    
    public Parser(CovidDataFunctions covidDataFunc) {
    	this.covidDataFunc = covidDataFunc;
    }
    
    //REST METHODS
    
    //get all countries' covid data
    @GET
    @Path("/country")
    @Produces("application/json") 
    public List<CovidData> displayCountry(){
    	//call findAll() method from CovidDataFunctions
    	return covidDataFunc.findAll();    	
    }
        
    //get list of users
    @GET
    @Path("/users")
    @Produces("application/json") 
    public List<User> displayUsers(){
    	//call findAll() method from CovidDataFunctions
    	return covidDataFunc.findAllUsers();    	
    }
    
    
    //add new user
    @POST
    @Path("/adduser")
    @Consumes("application/json")
    public String createUser(User user) {
    	//persist new user using UserDAO object
    	uDAO.persist(user);
    	return "New User Created";
    }
    
    //add more covid data
    @POST
    @Path("/addcoviddata/{role}")
    @Consumes("application/json")
    public String createNewData(@PathParam("role")String role, CovidData cd) {
    	//if the user is an admin, they can add another country's covid data
    	if(role.equalsIgnoreCase("admin")) {
    		cdDAO.persist(cd);
    		return "New Data has been added to the list";
    	} else { 
    		//else, return error message
    		return "Only admins may add new data";
    	}
    }
    
    
    //update user info
    @PUT
    @Path("/updateuser/{username}")
    @Consumes("application/json")
    public String updateUser(@PathParam("username")String newUsername) {
    	User user = new User();
    	user.setUsername(newUsername);
    	uDAO.update(user);
    	return "User details have been updated";
    }
    
    //update covid data info
    @PUT
    @Path("/updatecoviddata/{role}")
    @Consumes("application/json")
    public String updateData(@PathParam("role")String role, CovidData cd) {
    	//if user is an admin, they can update a country's covid data
    	if(role.equalsIgnoreCase("admin")) {
    		cdDAO.update(cd);
    		return "Data has been updated";
    	} else { // else return an error message
    		return "Only admins may update data";
    	}
    }
    
    
    //delete user
    @DELETE 
    @Path("/deleteuser/{username}")
    @Consumes("application/json")
    public String deleteUser(@PathParam("username") String delUsername) {
    	if(delUsername.equalsIgnoreCase(user.getUsername())) {
    		uDAO.remove(delUsername);
    		return "User has been removed";
    	}else {
    		return "User not found and cannot be deleted";
    	}
    }
    

    //delete covid data info
    @DELETE 
    @Path("/deletecountry/{role}/{countryName}")
    @Consumes("application/json")
    public String deleteCountry(@PathParam("countryName") String countryName, String role) {
    	//if user is an admin, they can delete a country's covid data
    	if(role.equalsIgnoreCase("admin")) {
    		uDAO.remove(countryName);
    		return "Country has been removed";
    	}else { // else, return an error message
    		return "Only admin can delete data";
    	}
    }
    

  
  }
  
