package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.CovidData;
import entities.User;

public class UserDAO {
	
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("covidPU");
	protected static EntityManager em;

	
	public UserDAO() {		
	}
	
	//persist method
	public void persist(User user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		em.close();
		}
	
		//list all users method
		@SuppressWarnings("unchecked")
		public List<CovidData> findAllUsers(){
			return em.createQuery("from user").getResultList();
		}
		
		//update user method
		public User update(User user) {
			em.getTransaction().begin();
			user = em.merge(user);
			em.getTransaction().commit();
			return user;
		}
		
		//delete user method
		public void remove(String username) {
			em.getTransaction().begin();
			em.remove(em.find(User.class, username));
			em.getTransaction();
		}

}
