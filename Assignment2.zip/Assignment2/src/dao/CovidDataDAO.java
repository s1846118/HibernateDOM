package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.CovidData;
import entities.User;

public class CovidDataDAO {
	
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("covidPU");
	protected static EntityManager em;
	
	public CovidDataDAO() {
	}
	
	//persist method
	public void persist(CovidData covidData) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(covidData);
		em.getTransaction().commit();
		em.close();
	}
	
	//list all country covid data method
	@SuppressWarnings("unchecked")
	public List<CovidData> findAll(){
		return em.createQuery("from coviddata").getResultList();
	}
	
	//update covid data method
	public CovidData update(CovidData covidData) {
		em.getTransaction().begin();
		covidData = em.merge(covidData);
		em.getTransaction().commit();
		return covidData;
	}
	
	//delete country covid data method
	public void removeCountry(String country) {
		em.getTransaction().begin();
		em.remove(em.find(CovidData.class, country));
		em.getTransaction();
	}

}
