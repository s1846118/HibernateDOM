import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadUsers {
	
	public static void main(String args[]) throws
	IOException, ParserConfigurationException, SAXException {
		
		File xmlFile = new File("users.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		
		System.out.println("Root Element: " + doc.getDocumentElement().getNodeName());
		
		NodeList users = doc.getElementsByTagName("user");
		
		for(int i =0; i< users.getLength(); i++) {
			Node user = users.item(i);
			
			System.out.println("\nCurrent Element: " + user.getNodeName());
			
			if (user.getNodeType() == Node.ELEMENT_NODE) {
				Element elem = (Element) user;
				
				String uid = elem.getAttribute("id");
				
				Node firstname = elem.getElementsByTagName("firstname").item(0);
				String fname = firstname.getTextContent();
				
				Node node2 = elem.getElementsByTagName("lastname").item(0);
				String lname = node2.getTextContent();
				
				Node node3 = elem.getElementsByTagName("occupation").item(0);
				String occup = node3.getTextContent();
				
				System.out.println("User ID: " + uid);
				System.out.println("First Name: " + fname);
				System.out.println("Last Name: " + lname);
				System.out.println("Occupation " + occup);
				
			}
		}
	}

}
