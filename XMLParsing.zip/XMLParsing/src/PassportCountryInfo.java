import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

// using dom, parse the dataset containing all the stats on passports issued by country of birth

public class PassportCountryInfo {

	public static void main(String args[]) throws IOException, ParserConfigurationException, SAXException {
		
		File xmlFile = new File("Passports.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		
		System.out.println("Root Element: " + doc.getDocumentElement().getNodeName());
		
		NodeList passports = doc.getElementsByTagName("AnnualTotals");
		
		for (int i=0; i < passports.getLength(); i++) {
			Node passport = passports.item(i);
			
			System.out.println("\nCurrent Element: " + passport.getNodeName());
			
			if (passport.getNodeType() == Node.ELEMENT_NODE) {
				Element elem = (Element) passport;
				
				//String uid = elem.getAttribute("id");
				
				Node yearOfIssue = elem.getElementsByTagName("YearofIssue").item(0);
				String year = yearOfIssue.getTextContent();
				
				Node countryOfBirth = elem.getElementsByTagName("CountryOfBirth").item(0);
				String country = countryOfBirth.getTextContent();
				
				Node appType = elem.getElementsByTagName("ApplicantType").item(0);
				String applicationType = appType.getTextContent();
				
				Node totalIssued = elem.getElementsByTagName("TotalIssued").item(0);
				String total = totalIssued.getTextContent();
				
				System.out.println("Year Of Issue: " + year);
				System.out.println("Country of Birth: " + country);
				System.out.println("Application Type:  " + applicationType);
				System.out.println("Total Issued: " + total);
				
			}
		}
		
		
	}
}
