import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MostPassports {
public static void main(String args[]) throws IOException, ParserConfigurationException, SAXException {
		
		File xmlFile = new File("Passports.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		
		System.out.println("Root Element: " + doc.getDocumentElement().getNodeName());
		
		NodeList passports = doc.getElementsByTagName("AnnualTotals");
		

}
}
