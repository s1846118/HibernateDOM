package main;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import entities.Country;
import entities.Variant;

public class MainTest {
	
	@GET//1
	@Path("/country")
	@Produces("application/xml")
	public List<User> displayCountry() {
		ArrayList<User> cList = (ArrayList<Country>) cDAO.getAllLots();
		for(Country c: cList) {
			System.out.println("Country: "+c.getCountry());
			System.out.println("Indicator: "+ c.getIndicator());
			System.out.println("Year-Week: "+ c.getYear_Week());
			System.out.println("Value: "+ c.getValue());
			System.out.println("Country Code: " + c.getCountryCode());	
		}
		return cList;
	}
	
	
	@GET//2
	@Path("/json/country")
	@Produces("application/json")
	public List<Country> displayJSONCountry() {
		ArrayList<Country> cList = (ArrayList<Country>) cDAO.getAllLots();
		for(Country c: cList) {
			System.out.println("Country: "+c.getCountry());
			System.out.println("Indicator: "+ c.getIndicator());
			System.out.println("Year-Week: "+ c.getYear_Week());
			System.out.println("Value: "+ c.getValue());
			System.out.println("Country Code: " + c.getCountryCode());	
		}
		return cList;
	}
	
	@GET//3
	@Path("/variant")
	@Produces("application/xml")
	public List<Variant> displayCountryVariant() {
		ArrayList<Variant> vList = (ArrayList<Variant>) vDAO.getAllLots();
		for(Variant v: vList) {
			System.out.println("Country: "+ v.getCountry());
			System.out.println("Country Code: "+ v.getCountry_code());
			System.out.println("Variant: "+ v.getVariant());
			System.out.println("Number of Variant Detected: "+ v.getNoVarDetec());
				
		}
		return vList;
	}
	
	
	@GET//4
	@Path("/variant")
	@Produces("application/xml")
	public List<Variant> displayJSONCountryVariant() {
		ArrayList<Variant> vList = (ArrayList<Variant>) vDAO.getAllLots();
		for(Variant v: vList) {
			System.out.println("Country: "+ v.getCountry());
			System.out.println("Country Code: "+ v.getCountry_code());
			System.out.println("Variant: "+ v.getVariant());
			System.out.println("Number of Variant Detected: "+ v.getNoVarDetec());			
		}
		return vList;
	}
	
	

}
