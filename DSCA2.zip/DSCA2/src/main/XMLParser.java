//put everything in xmlparser class method - add extends stuff
//then add public static void method at bottom and call class
//create dp methods that help separeate and create relations between data (ccheck MY_DOM_parser class for details)
package main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import dao.CountryDAO;
import dao.VariantDAO;
import entities.Country;
import entities.Variant;

public class XMLParser {
	static Variant variantInfo;
	static String country;
	static String indicator;
	static String year_week;
	static String value;
	static String vCountry;
	static String vCountryCode;
	static String vYear_week;
	static String variant;
	static String numberDetec;
	

	
	
public static void main(String args[]) throws IOException, ParserConfigurationException, SAXException {
		
	File xmlFile2 = new File("variant.xml");
	
	DocumentBuilderFactory factory2 = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder2 = factory2.newDocumentBuilder();
	Document doc2 = builder2.parse(xmlFile2);
	
	System.out.println("Root Element: " + doc2.getDocumentElement().getNodeName());
	
	NodeList variantData = doc2.getElementsByTagName("fme:Sheet");
	
	for(int i=0; i<variantData.getLength(); i++) {
		Node varData = variantData.item(i);
		
		
		if(varData.getNodeType() == Node.ELEMENT_NODE) {
			
			Element elem = (Element) varData;
			
			//for(Country country L co)
			//then add forloop here and go through it with array list

			Node count = elem.getElementsByTagName("fme:country").item(0);
			 vCountry = count.getTextContent();
			Node count_code = elem.getElementsByTagName("fme:country_code").item(0);
			 vCountryCode = count_code.getTextContent();
			Node yearWeek = elem.getElementsByTagName("fme:year_week").item(0);
			 vYear_week = yearWeek.getTextContent();
			
			Node src = elem.getElementsByTagName("fme:source").item(0);
			String source = src.getTextContent();
			Node newCase = elem.getElementsByTagName("fme:new_cases").item(0);
			String new_cases = newCase.getTextContent();
			Node numberSeq = elem.getElementsByTagName("fme:number_sequenced").item(0);
			String number_sequenced = numberSeq.getTextContent();
			
			Node perCS = elem.getElementsByTagName("fme:percent_cases_sequenced").item(0);
			String percentCS = perCS.getTextContent();
			Node validD = elem.getElementsByTagName("fme:valid_denominator").item(0);
			String validDenom = validD.getTextContent();				
			Node var = elem.getElementsByTagName("fme:variant").item(0);
			 variant = var.getTextContent();
			
			Node noDV = elem.getElementsByTagName("fme:number_detections_variant").item(0);
			 numberDetec = noDV.getTextContent();
			Node noSKV = elem.getElementsByTagName("fme:number_sequenced_known_variant").item(0);
			String numberSKV = noSKV.getTextContent();
			Node perVar = elem.getElementsByTagName("fme:percent_cases_sequenced").item(0);
			String perVariant = perVar.getTextContent();
			
			//if(country.equalsIgnoreCase("Austria")) {
			/*
			 * System.out.println("\nCountry: " + vCountry);
			 * System.out.println("Country Code: " + vCountryCode);
			 * System.out.println("Year-Week: " + vYear_week); System.out.println("Source: "
			 * + source); System.out.println("New Cases: " + new_cases);
			 * System.out.println("Number Sequenced: " + number_sequenced);
			 * System.out.println("Percent Cases Sequenced: " + percentCS);
			 * System.out.println("Valid Denominator: " + validDenom);
			 * System.out.println("Variant: " + variant);
			 * System.out.println("Number Detections Variant: " + numberDetec);
			 * System.out.println("Number Sequenced Known Variant: " + numberSKV);
			 * System.out.println("Percent Variant: " + perVariant);
			 */	
				
				//create variant object with string valuables as above
				variantInfo = new Variant(vCountry, vCountryCode, variant, numberDetec);
				//create arraylist object of variant
				List<Variant> variantList = new ArrayList<>();
				//add actual object to arraylist
				variantList.add(variantInfo);
				System.out.println(variantInfo);
				
				VariantDAO vDAO = new VariantDAO();
				Variant v1 = new Variant(vCountry, vCountryCode, variant, numberDetec);
				vDAO.persist(v1);
				
				
				//Country countCode = new Country(null, null, null, countryCode);
				
				/*
				 * for(Variant varCountry: variantList) {
				 * //if(varCountry.getCountry().equalsIgnoreCase("Austria")) {
				 * System.out.println("\nCountry: " + variantInfo.getCountry());
				 * System.out.println("Country Code : " + variantInfo.getCountry_code());
				 * 
				 * System.out.println("Variant: " + variantInfo.getVariant());
				 * System.out.println("Number Detections Variant : " +
				 * variantInfo.getNoVarDetec()); //} }
				 */
				
			//}

		}

	}
	
	
	
	
	
	
	
	
		File xmlFile = new File("coviddata.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		
		System.out.println("Root Element: " + doc.getDocumentElement().getNodeName());
		
		NodeList data = doc.getElementsByTagName("fme:Sheet");
		
		for (int i=0; i < data.getLength(); i++) {
			Node stat = data.item(i);
			
//			System.out.println("\nCurrent Element: " + stat.getNodeName());
			
			if (stat.getNodeType() == Node.ELEMENT_NODE) {
				Element elem = (Element) stat;
				
				//String uid = elem.getAttribute("id");
				
				//Node count = elem.getElementsByTagName("fme:country").item(0);
				Node count = elem.getElementsByTagName("fme:country").item(0);
				country = count.getTextContent();
				Node ind = elem.getElementsByTagName("fme:indicator").item(0);
				indicator = ind.getTextContent();
				Node theDate = elem.getElementsByTagName("fme:date").item(0);
				String date = theDate.getTextContent();
				Node yearWeek = elem.getElementsByTagName("fme:year_week").item(0);
				 year_week = yearWeek.getTextContent();
				Node val = elem.getElementsByTagName("fme:value").item(0);
				 value = val.getTextContent();
				Node src = elem.getElementsByTagName("fme:source").item(0);
				String source = src.getTextContent();
				Node uRL = elem.getElementsByTagName("fme:url").item(0);
				String url = uRL.getTextContent();
				
				
				if(indicator.equalsIgnoreCase("Daily hospital occupancy")) {
					
					//if condition is true, then store the data (country, indicator, year_week and value)
					Country countryData = new Country(country, indicator, year_week, value, variantInfo.getCountry_code());
					//null
					List<Country> countryInfo =new ArrayList<>();
					countryInfo.add(countryData);	//store data in arraylist 
					//System.out.println(countryInfo);
					

					  CountryDAO cDAO = new CountryDAO(); 
					  Country c1 = new Country(country, indicator, year_week, value, variantInfo.getCountry_code());
					  cDAO.persist(c1);
					 
					  					
					
					//Variant varCode = new Variant(null, null, null, null);
					//varCode.getCountry_code();
					//countryData.setCountryCode(varCode.getCountry_code());
					
					
					/*
					 * for(Country countryVar : countryInfo) {
					 * //if(countryVar.getCountry().equalsIgnoreCase("Sweden")) {
					 * System.out.println("\nCountry: " + countryData.getCountry());
					 * System.out.println("Country Code: " + countryData.getCountryCode());
					 * System.out.println("Indicator : " + countryData.getIndicator());
					 * System.out.println("Value : " + countryData.getValue());
					 * System.out.println("Year & Week : " + countryData.getYear_Week());
					 * 
					 * //} }
					 */
				}

						
				
	
				
			}
		

}
/*
 * CountryDAO cDAO = new CountryDAO(); Country c1 = new Country(country,
 * indicator, year_week, value, variantInfo.getCountry_code());
 * cDAO.persist(c1);
 */
		/*
		 * VariantDAO vDAO = new VariantDAO(); Variant v1 = new Variant(vCountry,
		 * vCountryCode, variant, numberDetec); vDAO.persist(v1);
		 */




		//GET METHODS
		//view lot list in xml format
	














}



	
	
		
		//pass ad run strings
				
				//call cdao.persist(country)
		
		/*
		 * Country c1 = new Country(country, indicator, year_week, value,
		 * variantInfo.getCountry_code()); coun
		 */


}
