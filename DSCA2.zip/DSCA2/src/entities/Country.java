package entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Country {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	//identifiers can be generated in the DB by specifying @GeneratedValue on the identifier (int id)
	int id; // will be used as the primary key
	
	String country;
	String indicator;
	String year_Week;
	String value;
	String countryCode;
	//have country code 
	
	//might need to create object here instead!!!
	
	public Country() {
		
	}
	
	
	  public Country(String country, String indicator, String year_Week, String value, String countryCode) {
		super();
		this.country = country;
		this.indicator = indicator;
		this.year_Week = year_Week;
		this.value = value;
		this.countryCode = countryCode;
	}
	  
	 
	public String getCountry() {
		return country;
	}

	public String getIndicator() {
		return indicator;
	}

	public String getYear_Week() {
		return year_Week;
	}


	public String getValue() {
		return value;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}


	public void setYear_Week(String year_Week) {
		this.year_Week = year_Week;
	}


	public void setValue(String value) {
		this.value = value;
	}
	
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}


	public String toString() { 
		return country + " " + indicator + " " + year_Week +
	  " " + year_Week + " " + value; 
		}
	 

}
