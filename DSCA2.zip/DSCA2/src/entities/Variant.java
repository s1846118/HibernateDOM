package entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Variant {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	//identifiers can be generated in the DB by specifying @GeneratedValue on the identifier (int id)
	int id;
	
	String country;
	String country_code;
	String variant;
	String noVarDetec;
	
	public Variant() {
		
	}
	
	public Variant(String country, String country_code, String variant, String noVarDetec) {
		super();
		this.country = country;
		this.country_code = country_code;
		this.variant = variant;
		this.noVarDetec = noVarDetec;
	}

	public String getCountry() {
		return country;
	}

	public String getCountry_code() {
		return country_code;
	}

	public String getVariant() {
		return variant;
	}

	public String getNoVarDetec() {
		return noVarDetec;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public void setNoVarDetec(String noVarDetec) {
		this.noVarDetec = noVarDetec;
	}
	
	 public String toString() { return country + " " + country_code + " " + variant +
			  " " + noVarDetec;
	 }
}
