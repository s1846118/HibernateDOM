package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Variant;

public class VariantDAO {
	
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("covidPU");
	
	public VariantDAO() {
		
	}
	
	public void persist(Variant variant) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(variant);
		em.getTransaction().commit();
		em.close();
	}

}
