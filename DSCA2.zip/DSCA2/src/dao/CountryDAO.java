package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Country;


public class CountryDAO {
	
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("covidPU");
	
	public CountryDAO() {
		
	}
	
	
	public void persist(Country country) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(country);
		em.getTransaction().commit();
		em.close();
	}
	
	
	
	
	

}
