//JPA/HIBERNATE
package main;

import java.util.ArrayList;
import java.util.List;

import dao.CommentDAO;
import dao.ProfileDAO;
import dao.SubscriberDAO;
import entities.Comment;
import entities.Profile;
import entities.Subscriber;

public class Test {
	
	
	public Test() {
		SubscriberDAO sDAO = new SubscriberDAO();
		ProfileDAO pDAO = new ProfileDAO();
		CommentDAO cDAO = new CommentDAO();
		
		//Add comments
		Comment c1 = new Comment("Steve loves apples"); //c1 gets returned
		Comment c2 = new Comment("Steve hates bananas");
		Comment c3 = new Comment("Steve loves dogs");
		cDAO.persist(c1);
		cDAO.persist(c2);
		cDAO.persist(c3);
		
		List<Comment> comments = new ArrayList<Comment>();
		comments.add(c1);
		comments.add(c2);
		comments.add(c3);
		//Add Profile
		Profile profile = new Profile("Steve's cool profile", comments);
		//'.persist' is the key word - it updates the new data to the DB
		pDAO.persist(profile);
		
		//Add Subscriber
		Subscriber subscriber = new Subscriber("Steve","beans", profile );
		sDAO.persist(subscriber);
		
		//View all subscribers (here I've accessed all objects through the subscriber)
		ArrayList<Subscriber> subscribers = (ArrayList<Subscriber>) sDAO.getAllSubscribers();
		for(Subscriber s : subscribers) {
			System.out.println("Subscriber object username is "+s.getUsername());
			System.out.println("Subscriber's Profile says "+ s.getProfile().getDescription());
			//Note I've made an Eagar Fetch on the Comments List in Profile to enable this
			System.out.println("Subscriber's profile's first comment is "+s.getProfile().getComments().get(0).getContent());
		}
		
		//Update username using merge
		subscriber.setUsername("STEVO");
		sDAO.merge(subscriber);	
		
		//remove the last comment
		cDAO.remove(c3);
		
		//Get subscriber by username, print their password
		System.out.println(sDAO.getSubscriberByUsername("STEVO").getPassword());
		
	}
	
	public static void main(String[] args) {
		new Test();
	}

}
